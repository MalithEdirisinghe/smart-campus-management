module.exports = (sequelize, DataTypes) => {
    const Lecturer = sequelize.define('Lecturer', {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        lecturerId: { type: DataTypes.STRING, allowNull: false, unique: true },
        userId: { type: DataTypes.INTEGER, allowNull: false },
        firstName: { type: DataTypes.STRING, allowNull: false },
        lastName: { type: DataTypes.STRING, allowNull: false },
        department: { type: DataTypes.STRING, allowNull: false },
        specialization: { type: DataTypes.STRING, allowNull: true },
        batchNo: { type: DataTypes.STRING, allowNull: false },
        module: { type: DataTypes.STRING, allowNull: false },
        startDate: { type: DataTypes.DATE, allowNull: false },
        endDate: { type: DataTypes.DATE, allowNull: true }
    });

    Lecturer.associate = (models) => {
        Lecturer.belongsTo(models.User, { foreignKey: 'userId', as: 'user' });
    };

    return Lecturer;
};
